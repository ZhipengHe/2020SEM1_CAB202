/*	CAB202: Tutorial 1
*	Question 1 - Program 2
*
*	B.Talbot, February 2016
*	Queensland University of Technology
*/
#include <stdio.h>
#include "dummy_library.h"

int main() {
    // Print a welcome
    printf("Hello CAB202!\n");

    // Print from 1 to 10
    count_up_to_n(10);

    // Return from main
    return 0;
}
