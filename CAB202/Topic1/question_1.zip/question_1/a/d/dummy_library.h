/*	CAB202: Tutorial 1
*	Question 1 - Header for the dummy library
*
*	B.Talbot, February 2016
*	Queensland University of Technology
*/

void count_up_to_n(int n);
void count_down_from_n(int n);

double get_pi(void);
