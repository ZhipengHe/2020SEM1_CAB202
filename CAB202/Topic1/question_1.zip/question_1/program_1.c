/*	CAB202: Tutorial 1
*	Question 1 - Program 1
*
*	B.Talbot, February 2016
*	Queensland University of Technology
*/
#include <stdio.h>

int main() {
    // Print something to the console
    printf("Hello CAB202!\n");

    // Return from main
    return 0;
}
